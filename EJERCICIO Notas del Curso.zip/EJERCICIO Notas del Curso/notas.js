const notas = [];
const form = document.querySelector('form');
const promedio = document.getElementById('promedio');
const encima = document.getElementById('encima');

form.addEventListener('submit', function(event) {
    event.preventDefault();
    const nota = parseFloat(document.getElementById('nota').value);
    notas.push(nota);
    const suma = notas.reduce((a, b) => a + b, 0);
    const avg = suma / notas.length;
    promedio.textContent = avg.toFixed(2);
    const encimaPromedio = notas.filter(n => n > avg).length;
    encima.textContent = encimaPromedio;
});