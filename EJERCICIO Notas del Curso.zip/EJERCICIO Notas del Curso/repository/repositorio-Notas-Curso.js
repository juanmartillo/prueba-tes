class RepositorioNotasCurso {
  constructor() {
    this.notas = [];
  }

  agregarNota(nota) {
    if (nota < 0 || nota > 5) {
      throw new Error("La nota debe estar entre 0 y 5");
    }
    this.notas.push(nota);
  }

  calcularPromedio() {
    if (this.notas.length === 0) {
      return 0;
    }
    const total = this.notas.reduce((acum, nota) => acum + nota, 0);
    return total / this.notas.length;
  }

  contarEstudiantesEncimaDelPromedio() {
    const promedio = this.calcularPromedio();
    return this.notas.filter((nota) => nota > promedio).length;
  }
}
